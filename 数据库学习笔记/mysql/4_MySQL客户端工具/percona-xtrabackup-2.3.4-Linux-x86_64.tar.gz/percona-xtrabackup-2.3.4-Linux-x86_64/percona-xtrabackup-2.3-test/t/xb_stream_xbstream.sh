############################################################################
# Test streaming in the XBSTREAM format
############################################################################

stream_format=xbstream
stream_extract_cmd="xbstream -xv <"

. inc/xb_stream_common.sh
